#pragma once

void testAll();
void testFilter();
//bool isOdd(TElem element);
